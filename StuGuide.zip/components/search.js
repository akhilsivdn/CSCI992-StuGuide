import React from "react";

export class SearchComponent extends React.Component{
    constructor() {
        super();
        this.state = { }
      }



    render(){
        return(
          <div className="weatherDiv">
              <h1>Search page !</h1>
          </div>  
        );
    }
}